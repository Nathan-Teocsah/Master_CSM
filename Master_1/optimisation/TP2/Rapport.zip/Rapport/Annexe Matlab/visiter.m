function visiter(u,Tabuk,iter)
  %
  % permet de visualiser les iterations de l'algorithme du gradient
  %
  % variables entree:
  % u       = solution obtenue  argmin J(v)
  % Tabuk    = tableau contenant la suite (u_k) des points intermediaires
  %           u_k = (Tabuk(1,k),Tabuk(2,k))
  % iter    = nb d'iterations effectuees
  % itermax = nb max d'iterations autorisees


  global isov   % tableau des isovaleurs retournees par la fonction visiso.m
  global numex  % numero de l'exemple traite

  hold on
  plot(Tabuk(1,:),Tabuk(2,:),'ko')
  hold on
  plot(Tabuk(1,:),Tabuk(2,:),'k-')

  text(u(1),u(2),['  argmin =  (',num2str(u(1)),' , ', num2str(u(2)), ')'])
  xlabel(['nb d''it?rations = ',num2str(iter), ...
          '        ||grad J(u*)|| =  ',num2str(norm(GJ(u),2)), ...
          '          J(u*) =  ',num2str(J(u))])
  rep = input ('Voulez-vous afficher les isovaleurs (o/n) : ','s');
  if rep=='o'
    clabel(isov, 'labelspacing', 300);
  end
end
